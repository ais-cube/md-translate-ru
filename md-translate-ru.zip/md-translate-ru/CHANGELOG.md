# Changelog

## [1.0.0] - 2026-02-20

### Добавлено

- Основной скрипт перевода `translate_api.py`
- Поддержка глоссариев (`glossary.json`)
- Автоматическая разбивка больших файлов на чанки по заголовкам
- Anti-AI cleanup через HUMANIZER.md
- Batch API для двукратной экономии
- Dry-run режим для оценки стоимости
- Сбор терминов-кандидатов в `glossary_candidates.json`
- Примеры в `examples/`
